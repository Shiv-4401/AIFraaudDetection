import sys
import bcrypt
import sqlite3
import logging
import pandas as pd
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QPushButton, QVBoxLayout, QWidget, QFileDialog,
    QMessageBox, QComboBox, QHBoxLayout, QLineEdit, QDialog, QTableWidget, QTableWidgetItem,
    QTabWidget, QSizePolicy, QScrollArea,QHeaderView, QStackedLayout, QGraphicsOpacityEffect, QGraphicsDropShadowEffect)
from PyQt5.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve, QRect, QSequentialAnimationGroup, QPauseAnimation
from PyQt5.QtGui import QFont, QIcon, QPixmap, QMovie, QColor
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sb
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import tensorflow as tf
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Configuration Class
class ConfigurationManager:
    def get(self, section, option, default=None):
        if option == "database_name":
            return "users.db"
        return default

# Logger Class to provide log messages
class Logger:
    def get_log_msgs(self):
        logger = logging.getLogger("Fraud-Analyzer")
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.DEBUG)
        return logger

# logging and config initialization
config = ConfigurationManager()
logger = Logger().get_log_msgs()

# Register window for fresh users
class RegisterUser(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Register User")
        self.setFixedSize(400, 300)
        self.setWindowIcon(QIcon("icons/register.png"))

        # Layout
        window_layout = QVBoxLayout()
        window_layout.setContentsMargins(20, 20, 20, 20)
        window_layout.setSpacing(15)

        # Username Input
        self.user_name = QLineEdit(self)
        self.user_name.setPlaceholderText("Enter Username here")
        self.user_name.setFont(QFont('Arial', 12))
        self.user_name.setFixedHeight(40)

        # Password Input
        self.password = QLineEdit(self)
        self.password.setPlaceholderText("Enter Password here")
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setFont(QFont('Arial', 12))
        self.password.setFixedHeight(40)

        # Register Button
        register_button = QPushButton("Sign Up")
        register_button.setFont(QFont('Arial', 12))
        register_button.setCursor(Qt.PointingHandCursor)
        register_button.setIcon(QIcon("icons/signup_btn.png"))
        register_button.setIconSize(QSize(24, 24))
        register_button.clicked.connect(self.register_user)
        register_button.setFixedHeight(40)

        # Adding widgets
        window_layout.addWidget(QLabel("Create a New Profile", self))
        window_layout.addWidget(self.user_name)
        window_layout.addWidget(self.password)
        window_layout.addWidget(register_button)
        self.setLayout(window_layout)

    # Function for User Registration
    def register_user(self):
        username = self.user_name.text().strip()
        password = self.password.text().encode('utf-8')

        # Check whether Username and Password entered
        if not username or not password:
            QMessageBox.warning(self, "Input Error", "Please provide Username and Password!")
            return

        # Database Connection
        try:
            conn = sqlite3.connect(config.get("DATABASE", "database_name", "users.db"))
            cursor = conn.cursor()

            # Check if entered User exists already
            cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
            if cursor.fetchone():
                QMessageBox.warning(self, "Error", "Username exists already!")
                return

            # Password hashing and save User
            hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
            conn.commit()
            conn.close()

            QMessageBox.information(self, "Success", "Registration Successful!")
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Database error: {str(e)}")
            logger.error(f"Database error: {e}")

# Login Window
class Login(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Login")
        self.setFixedSize(500, 400)
        self.setWindowIcon(QIcon("icons/login.png"))
        self.setStyleSheet("""
            QDialog {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                                  stop:0 #2c3e50, stop:1 #bdc3c7);
                border-radius: 12px;
            }
            QLabel#Title {
                color: white;
                font-size: 25px;
                font-weight: bold;
            }
            QLineEdit {
                padding: 10.5px;
                border: 2.5px solid #ccc;
                border-radius: 4px;
                font-size: 13px;
                background-color: rgba(255, 255, 255, 0.8);
            }
            QLineEdit:focus {
                border-color: #2980b9;
            }
            QPushButton#LoginBtn, QPushButton#registerBtn {
                background-color: #2980b9;
                color: white;
                padding: 10.5px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                min-width: 100px;
            }
            QPushButton#LoginBtn:hover, QPushButton#registerBtn:hover {
                background-color: #3498db;
            }
            QPushButton#registerBtn {
                background-color: #e67e22;
            }
            QPushButton#registerBtn:hover {
                background-color: #d35400;
            }
            QLabel#IconLabel {
                position: absolute;
            }
        """)

        # Entire login window layout
        layout_main = QVBoxLayout()
        layout_main.setContentsMargins(0, 0, 0, 0)
        layout_main.setSpacing(0)

        # Container Widget
        container = QWidget()
        layout_container = QVBoxLayout()
        layout_container.setContentsMargins(42, 42, 42, 42)
        layout_container.setSpacing(21)
        container.setLayout(layout_container)

        # Shadow Effect for Container
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(22)
        shadow.setXOffset(0)
        shadow.setYOffset(0)
        shadow.setColor(QColor(0, 0, 0, 150))
        container.setGraphicsEffect(shadow)

        # Heading
        title = QLabel("Welcome to Fraud-Analyzer!", self)
        title.setObjectName("Heading")
        title.setAlignment(Qt.AlignCenter)
       
        # Username Input
        self.user_name = QLineEdit(self)
        self.user_name.setPlaceholderText("Enter Username here")
        self.user_name.setFont(QFont('Arial', 12))
        self.user_name.setFixedHeight(40)
        self.user_name.setClearButtonEnabled(True)
        self.user_name.setStyleSheet("""
            QLineEdit {
                padding-left: 40px;
            }
        """)
        # Icon
        icon_username = QLabel(self)
        pixmap_username = QPixmap("icons/user_icon.png").scaled(20, 20, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        icon_username.setPixmap(pixmap_username)
        icon_username.setStyleSheet("background: transparent;")
        icon_username.setFixedSize(20, 20)
        icon_username.move(self.user_name.x() + 10, self.user_name.y() + 10)
        icon_username.setParent(self.user_name)

        # Password Input
        self.password = QLineEdit(self)
        self.password.setPlaceholderText("Enter password here")
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setFont(QFont('Arial', 12))
        self.password.setFixedHeight(40)
        self.password.setClearButtonEnabled(True)
        self.password.setStyleSheet("""
            QLineEdit {
                padding-left: 40px;
            }
        """)
        # Icon
        icon_password = QLabel(self)
        pixmap_password = QPixmap("icons/password_icon.png").scaled(20, 20, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        icon_password.setPixmap(pixmap_password)
        icon_password.setStyleSheet("background: transparent;")
        icon_password.setFixedSize(20, 20)
        icon_password.move(self.password.x() + 10, self.password.y() + 10)
        icon_password.setParent(self.password)

        # Button
        layout_btn = QHBoxLayout()
        layout_btn.setSpacing(22)

        # Login Button
        login_btn = QPushButton("Login")
        login_btn.setObjectName("LoginBtn")
        login_btn.setCursor(Qt.PointingHandCursor)
        login_btn.setIcon(QIcon("icons/login_btn.png"))
        login_btn.setIconSize(QSize(24, 24))
        login_btn.clicked.connect(self.authenticate_user)
        login_btn.setFixedHeight(40)

        # register Button
        register_btn = QPushButton("Register")
        register_btn.setObjectName("registerBtn")
        register_btn.setCursor(Qt.PointingHandCursor)
        register_btn.setIcon(QIcon("icons/register_btn.png"))
        register_btn.setIconSize(QSize(24, 24))
        register_btn.clicked.connect(self.open_register_window
)
        register_btn.setFixedHeight(40)

        layout_btn.addWidget(login_btn)
        layout_btn.addWidget(register_btn)

        # Adding widgets to container
        layout_container.addWidget(title)
        layout_container.addWidget(self.user_name)
        layout_container.addWidget(self.password)
        layout_container.addLayout(layout_btn)

        # Adding container to main window
        layout_main.addWidget(container)
        self.setLayout(layout_main)

    # Open Registration Window
    def open_register_window(self):
        register_window = RegisterUser()
        register_window.exec_()

    # Method to Authenticate User
    def authenticate_user(self):
        username = self.user_name.text().strip()
        password = self.password.text().encode('utf-8')

        # Check whether Username and Password entered
        if not username or not password:
            QMessageBox.warning(self, "Input Error", "Please provide Username and Password!")
            return

        # Database connection to fetch password
        try:
            conn = sqlite3.connect(config.get("DATABASE", "database_name", "users.db"))
            cursor = conn.cursor()
            cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
            result = cursor.fetchone()
            conn.close()

            if result and bcrypt.checkpw(password, result[0]):
                QMessageBox.information(self, "Success", "Login successful!")
                self.accept()
            else:
                QMessageBox.warning(self, "Error", "Oops! incorrect Username or Password")
                self.password.clear()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Database error: {str(e)}")
            logger.error(f"Database error: {e}")

# Canvas to generate resulting graphs
class Canvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig, self.ax = plt.subplots(figsize=(width, height), dpi=dpi)
        super(Canvas, self).__init__(self.fig)

# Main Application Window
class FraudAnalyzerApplication(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Fraud-Analyzer: Find your Fradulent Transactions Here!')
        self.setMinimumSize(1001, 8001)
        self.setWindowIcon(QIcon("icons/app_icon.png"))

        # Center Layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout_main = QVBoxLayout()
        central_widget.setLayout(layout_main)

        # Status Provider
        self.status_provider = self.statusBar()
        self.status_provider.showMessage("Start with Browse Files...")
        font = QFont('Arial', QFont.Bold)

        # Title
        self.heading = QLabel('Welcome to the Fraud Detection Platform!', self)
        self.heading.setAlignment(Qt.AlignCenter)
        font = QFont('Arial', 21, QFont.Bold)
        self.heading.setFont(font)
        self.heading.setStyleSheet("margin: 21px;")
        layout_main.addWidget(self.heading)

        # Animation for Heading
        self.animate_fade_in(self.heading, delay=510, duration=1000)

        # ML Model Selection Box
        ml_model_layout = QHBoxLayout()
        ml_model_layout.setContentsMargins(0, 10, 0, 10)
        ml_model_layout.setSpacing(20)

        self.dropdown_menu = QLabel('Select your Model', self)
        self.dropdown_menu.setFont(QFont('Arial', 14))
        self.dropdown_menu.setFixedWidth(200)
        
        self.select_model = QComboBox(self)
        self.select_model.setFont(QFont('Arial', 14))
        self.select_model.addItem("Logistic Regression")
        self.select_model.addItem("Neural Network")
        self.select_model.setFixedHeight(40)
        self.select_model.setContentsMargins(2, 0, 0, 0)

        ml_model_layout.addStretch()
        ml_model_layout.addWidget(self.dropdown_menu)
        ml_model_layout.addWidget(self.select_model)
        ml_model_layout.addStretch()
        
        layout_main.addLayout(ml_model_layout)
             
        # Hover Animation
        self.animate_hover(self.select_model)

        # Browse File Button
        self.browse_file_btn = QPushButton('Browse CSV File')
        self.browse_file_btn.setFont(QFont('Arial', 18))
        self.browse_file_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 10px 22px;
                margin: 0px 0px 15px 0px;
                font-size: 18px;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        self.browse_file_btn.setCursor(Qt.PointingHandCursor)
        self.browse_file_btn.setIcon(QIcon("icons/browse.png"))
        self.browse_file_btn.setIconSize(QSize(25, 25))
        self.browse_file_btn.clicked.connect(self.browse_file_window)
        self.browse_file_btn.setFixedHeight(50)
        self.browse_file_btn.setContentsMargins(0, 2, 0, 20)

        # Hover Animation
        self.animate_hover(self.browse_file_btn)

        # Center the button
        layout_btn = QHBoxLayout()
        layout_btn.addStretch()
        layout_btn.addWidget(self.browse_file_btn)
        layout_btn.addStretch()
        layout_main.addLayout(layout_btn)

        # Create Tab Bar
        self.tab_bar = QTabWidget()
        self.tab_bar.setTabPosition(QTabWidget.North)
        self.tab_bar.setTabShape(QTabWidget.Rounded)
        self.tab_bar.setFont(QFont('Arial', 12))
        layout_main.addWidget(self.tab_bar)
        
        # Home Tab (Main Page)
        self.home_tab = QWidget()
        self.tab_bar.addTab(self.home_tab, QIcon("icons/home.png"), "Home")
        self.home_tab_layout()

        # Visualization Tab
        self.visualization_tab = QWidget()
        self.tab_bar.addTab(self.visualization_tab, QIcon("icons/visualize.png"), "Visualization")
        self.visualization_tab_layout()

        # Export Tab
        self.export_tab = QWidget()
        self.tab_bar.addTab(self.export_tab, QIcon("icons/export.png"), "Export Report")  
        self.export_tab_layout()

        # Fraudulent Transactions Tab
        self.fraud_tab = QWidget()
        self.tab_bar.addTab(self.fraud_tab, QIcon("icons/fraud.png"), "Fraudulent Transactions")  
        self.fraud_tab_layout()
        
        default_style = """
                QWidget {
                    background-color: white;
                    color: black;
                }
                QPushButton {
                    background-color: #4CAF50;
                    color: white;
                    padding: 10px 20px;
                    font-size: 16px;
                    border: 1px solid #4CAF50; 
                    border-radius: 10px;
                }
                QPushButton:hover {
                    background-color: #45a049;
                }
                QLineEdit, QComboBox, QTableWidget {
                    background-color: white;
                    color: #3c3c3c;
                    border: 1px solid #555555;
                }
                QLabel {
                    color: #2b2b2b;
                }
                QTabWidget::pane
                    border-top: 2px solid #d8d8d8;
                }
                QTabBar::tab {
                    background: silver;
                    color: #3c3c3c;
                    padding: 10px;
                }
                QTabBar::tab:selected {
                    background: #4CAF50;
                }
            """
        self.setStyleSheet(default_style)
            
        # Dark Mode Button
        self.dark_mode_btn = QPushButton("Enable Dark Mode")
        self.dark_mode_btn.setFont(QFont('Arial', 14))
        self.dark_mode_btn.setCursor(Qt.PointingHandCursor)
        self.dark_mode_btn.setStyleSheet("""
            QPushButton {
                background-color: #555555;
                color: white;
                padding: 10px 20px;
                font-size: 14px;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #666666;
            }
        """)
        self.dark_mode_btn.clicked.connect(self.enable_dark_mode)

        # Animation to Dark Mode Button
        self.animate_hover(self.dark_mode_btn)
        self.animate_fade_in(self.dark_mode_btn, delay=1000, duration=1000)

        # positioning dark mode button
        top_layout = QHBoxLayout()
        top_layout.addStretch()
        top_layout.addWidget(self.dark_mode_btn)
        layout_main.insertLayout(0, top_layout)
       
        # Add Spinner
        self.label_loading = QLabel(self)
        self.label_loading.setAlignment(Qt.AlignCenter)
        self.movie_loading = QMovie("icons/loading.gif")
        if not self.movie_loading.isValid():
            logger.error("Loading spinner GIF not found!")
            QMessageBox.warning(self, "Image Not Found", "Loading spinner GIF not found!")
        self.label_loading.setMovie(self.movie_loading)
        self.label_loading.setFixedSize(50, 50)
        self.label_loading.hide()
        layout_main.addWidget(self.label_loading, alignment=Qt.AlignCenter)

        # Add Animation for Spinner
        self.spinner_animation = QPropertyAnimation(self.label_loading, b"geometry")
        self.spinner_animation.setDuration(500)
        self.spinner_animation.setEasingCurve(QEasingCurve.InOutQuad)
        self.spinner_animation.setStartValue(QRect(445, 345, 95, 95))
        self.spinner_animation.setEndValue(QRect(445, 345, 95, 95))
        self.spinner_animation.setLoopCount(-1) 
        
    # Home tab design
    def home_tab_layout(self):
        layout = QStackedLayout()
        self.home_tab.setLayout(layout)

        # Background Image
        bg_label = QLabel()
        bg_pixmap = QPixmap("icons/background.jpg") 
        if bg_pixmap.isNull():
            logger.error("Background image not found!")
            QMessageBox.warning(self, "Image Not Found", "Background image not found!")
        bg_label.setPixmap(bg_pixmap)
        bg_label.setScaledContents(True)
        bg_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # Overlay Text
        overlay_lable = QLabel("AI Fraud Detection System", self.home_tab)
        overlay_lable.setFont(QFont('Arial', 23, QFont.Bold))
        overlay_lable.setStyleSheet("color: white;")
        overlay_lable.setAlignment(Qt.AlignCenter)

        self.animate_fade_in(overlay_lable, delay=1500, duration=1000)

        # Add widgets to layout
        layout.addWidget(bg_label)
        layout.addWidget(overlay_lable)

    # Visualization tab design
    def visualization_tab_layout(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
       
        # Data Insights Labeling
        self.data_insights_lable = QLabel("Data Insights will appear here after processing a file.")
        self.data_insights_lable.setFont(QFont('Arial', 12))
        self.data_insights_lable.setAlignment(Qt.AlignLeft)
        self.data_insights_lable.setWordWrap(True)
        layout.addWidget(self.data_insights_lable)

        # Peak Fraud Hours Labeling
        self.peak_fraud_lable = QLabel("Peak Fraud Hours will appear here after processing a file.")
        self.peak_fraud_lable.setFont(QFont('Arial', 12))
        self.peak_fraud_lable.setAlignment(Qt.AlignLeft)
        self.peak_fraud_lable.setWordWrap(True)
        layout.addWidget(self.peak_fraud_lable)

        graphs_layout = QHBoxLayout()
        graphs_layout.setSpacing(20)
        
        # Transaction Trends graph
        self.transaction_canvas = Canvas(self, width=5, height=5, dpi=100)
        graphs_layout.addWidget(self.transaction_canvas)

        # Confusion Matrix Graph
        self.cm_canvas = Canvas(self, width=5, height=5, dpi=100)
        graphs_layout.addWidget(self.cm_canvas)

        # Buttons to Save Graphs
        save_buttons_layout = QHBoxLayout()
        save_buttons_layout.setSpacing(20)

        # Save Transaction Trends Image Btn
        self.save_transaction_btn = QPushButton("Save Transaction Trends Graph")
        self.save_transaction_btn.setFont(QFont('Arial', 12))
        self.save_transaction_btn.setCursor(Qt.PointingHandCursor)
        self.save_transaction_btn.setIcon(QIcon("icons/save.png"))
        self.save_transaction_btn.setIconSize(QSize(24, 24))
        self.save_transaction_btn.clicked.connect(self.save_trends_graph)
        save_buttons_layout.addWidget(self.save_transaction_btn)
        
        # Save Confusion Matrix Image Button
        self.save_cm_btn = QPushButton("Save Confusion Matrix")
        self.save_cm_btn.setFont(QFont('Arial', 12))
        self.save_cm_btn.setCursor(Qt.PointingHandCursor)
        self.save_cm_btn.setIcon(QIcon("icons/save.png"))
        self.save_cm_btn.setIconSize(QSize(24, 24))
        self.save_cm_btn.clicked.connect(self.save_cm_graph)
        save_buttons_layout.addWidget(self.save_cm_btn)

        layout.addLayout(graphs_layout)
        layout.addLayout(save_buttons_layout)

        self.visualization_tab.setLayout(layout)
        
    # To save Trends graph when clicked on button
    def save_trends_graph(self):
        if not hasattr(self, 'data'):
            QMessageBox.warning(self, "No Data Available", "Transactions Trends Graph is Not Available")
            return

        file_location, _ = QFileDialog.getSaveFileName(self, "Save Transaction Trends Graph", "", "PNG Files (*.png);;JPEG Files (*.jpg)", options=QFileDialog.Options())
        if file_location:
            try:
                self.transaction_canvas.fig.savefig(file_location)
                QMessageBox.information(self, "Success", f"Transaction Trends Graph saved to {file_location}")
                self.status_provider.showMessage("Transaction Trends Graph saved successfully!", 5000)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save Transaction Trends Graph: {str(e)}")
                logger.error(f"Failed to save Transaction Trends image: {e}")
                self.status_provider.showMessage("Failed to save Transaction Trends Graph.", 5000)
        else:
            QMessageBox.warning(self, "Warning", "No file path selected!")
            self.status_provider.showMessage("Canceled!", 5000)

    # To save Confusion Matrix when clicked on button
    def save_cm_graph(self):
        if not hasattr(self, 'confusion_matrix'):
            QMessageBox.warning(self, "No Data Available", "Comfusion Matrix is Not Available!")
            return

        file_location, _ = QFileDialog.getSaveFileName(self, "Save Confusion Matrix Image", "", "PNG Files (*.png);;JPEG Files (*.jpg)", options=QFileDialog.Options())
        if file_location:
            try:
                self.cm_canvas.fig.savefig(file_location)
                QMessageBox.information(self, "Success", f"Confusion Matrix saved to {file_location}")
                self.status_provider.showMessage("Confusion Matrix saved successfully!", 5000)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save Confusion Matrix: {str(e)}")
                logger.error(f"Failed to save Confusion Matrix: {e}")
                self.status_provider.showMessage("Failed to save Confusion Matrix!", 5000)
        else:
            QMessageBox.warning(self, "Warning", "No file path selected!")
            self.status_provider.showMessage("Confusion Matrix canceled!", 5000)

    # Export tab design
    def export_tab_layout(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(50, 50, 50, 50)
        layout.setSpacing(20)

        # PDF Export Button
        self.pdf_export_btn = QPushButton('Export PDF Report')
        self.pdf_export_btn.setFont(QFont('Arial', 16))
        self.pdf_export_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                padding: 10px 20px;
                font-size: 16px;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #0b7dda;
            }
        """)
        self.pdf_export_btn.setCursor(Qt.PointingHandCursor)
        self.pdf_export_btn.setIcon(QIcon("icons/pdf.png"))  
        self.pdf_export_btn.setIconSize(QSize(24, 24))
        self.pdf_export_btn.clicked.connect(self.pdf_report_generator)
        self.pdf_export_btn.setEnabled(False)
        layout.addWidget(self.pdf_export_btn)

        self.animate_hover(self.pdf_export_btn)

        # Excel Report Export Btn
        self.excel_export_btn = QPushButton('Export Excel Report')
        self.excel_export_btn.setFont(QFont('Arial', 16))
        self.excel_export_btn.setStyleSheet("""
            QPushButton {
                background-color: #FF9800;
                color: white;
                padding: 10px 20px;
                font-size: 16px;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #e68900;
            }
        """)
        self.excel_export_btn.setCursor(Qt.PointingHandCursor)
        self.excel_export_btn.setIcon(QIcon("icons/excel.png"))  
        self.excel_export_btn.setIconSize(QSize(24, 24))
        self.excel_export_btn.clicked.connect(self.excel_report_generator)
        self.excel_export_btn.setEnabled(False)
        layout.addWidget(self.excel_export_btn)

        self.animate_hover(self.excel_export_btn)

        self.export_tab.setLayout(layout)

    # Fradulent Transactions tab design
    def fraud_tab_layout(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Show Fraudulent Transactions Btn
        self.show_fraud_btn = QPushButton('Show Fraudulent Transactions')
        self.show_fraud_btn.setFont(QFont('Arial', 16))
        self.show_fraud_btn.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                padding: 10px 20px;
                font-size: 16px;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #da190b;
            }
        """)
        self.show_fraud_btn.setCursor(Qt.PointingHandCursor)
        self.show_fraud_btn.setIcon(QIcon("icons/fraud_btn.png"))  
        self.show_fraud_btn.setIconSize(QSize(24, 24))
        self.show_fraud_btn.clicked.connect(self.show_fraud_data)
        self.show_fraud_btn.setEnabled(False)
        layout.addWidget(self.show_fraud_btn)

        self.animate_hover(self.show_fraud_btn)

        # Fradulent Data Table
        self.fraud_data_table = QTableWidget()
        self.fraud_data_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.fraud_data_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.fraud_data_table.setSelectionMode(QTableWidget.SingleSelection)
        self.fraud_data_table.horizontalHeader().setStretchLastSection(True)
        self.fraud_data_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.fraud_data_table)
        layout.addWidget(scroll)

        self.fraud_tab.setLayout(layout)

    # Neural Network Model Logic
    def neural_network_model(self, input_dim):
        model = tf.keras.models.Sequential([
            tf.keras.layers.Dense(64, activation='relu', input_shape=(input_dim,)),
            tf.keras.layers.Dense(32, activation='relu'),
            tf.keras.layers.Dense(1, activation='sigmoid')
        ])
        model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
        return model

    # Browse File Window
    def browse_file_window(self):
        file_location, _ = QFileDialog.getOpenFileName(self, "CSV File", "~", "CSV Files (*.csv)")
        if file_location:
            self.heading.setText(f"Selected File: {file_location}")
            self.status_provider.showMessage("Processing file...")
            QApplication.processEvents()

            # Show Spinner
            self.label_loading.show()
            self.movie_loading.start()

            try:
                self.file_processing(file_location)
                QMessageBox.information(self, "Success", "File uploaded and processed successfully!")
                self.status_provider.showMessage("File processed successfully.", 5000)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"File processing failed!: {str(e)}")
                self.status_provider.showMessage("File processing failed.", 5000)
            finally:
                # Hide Spinner
                self.movie_loading.stop()
                self.label_loading.hide()
        else:
            QMessageBox.warning(self, "Warning", "No file selected.")
            self.status_provider.showMessage("No file selected.", 5000)

    # Display data present in selected dataset
    def show_file_data(self, data):
        total_transactions = len(data)
        fraud_cases = data['Class'].sum() if 'Class' in data.columns else 0
        fraud_percentage = (fraud_cases / total_transactions) * 100 if total_transactions > 0 else 0

        data_insights = (
            f"<b>Total Transactions:</b> {total_transactions}<br>"
            f"<b>Fraud Cases:</b> {fraud_cases}<br>"
            f"<b>Fraud Percentage:</b> {fraud_percentage:.2f}%"
        )
        self.data_insights_lable.setText(data_insights)

        # Generate Transaction Amounts Over Time Graph
        if 'Time' in data.columns and 'Amount' in data.columns and 'Class' in data.columns:
            self.transaction_canvas.ax.clear()
            # Normal transactions graph
            regular_transactions = data[data['Class'] == 0]
            self.transaction_canvas.ax.scatter(regular_transactions['Time'], regular_transactions['Amount'], 
                                          color='blue', alpha=0.5, label='Regular Transactions')

            # Fraudulent transactions graph
            fraudulent_transactions = data[data['Class'] == 1]
            self.transaction_canvas.ax.scatter(fraudulent_transactions['Time'], fraudulent_transactions['Amount'], 
                                          color='red', alpha=0.7, label='Fraudulent Transactions')

            self.transaction_canvas.ax.set_title("Transaction Amounts Over Time with Fraud Detection")
            self.transaction_canvas.ax.set_xlabel("Time")
            self.transaction_canvas.ax.set_ylabel("Transaction Amount")
            self.transaction_canvas.ax.legend()
            self.transaction_canvas.ax.grid(True)
            self.transaction_canvas.fig.tight_layout()
            self.transaction_canvas.draw()

            # Apply Animation to graph
            self.animate_fade_in(self.transaction_canvas, delay=0, duration=1000)

    # Display peak hours of Fradulent Transactions
    def display_peak_fraudulent_hours(self, data):
        try:
            if 'Time' not in data.columns or 'Class' not in data.columns:
                QMessageBox.warning(self, "Error", "Dataset must contain 'Time' and 'Class' columns for analysis.")
                return

            # If 'Time' is in seconds, change it to hours
            data['Hour'] = (data['Time'] // 3600) % 24
            fraudulent_hours = data[data['Class'] == 1].groupby('Hour').size()
            peak_hours = fraudulent_hours.idxmax() if not fraudulent_hours.empty else None
            peak_count = fraudulent_hours.max() if not fraudulent_hours.empty else 0

            if peak_hours is not None:
                peak_info = (
                    f"<b>Peak Fraud Hour:</b> {int(peak_hours)}:00<br>"
                    f"<b>Fraud Cases During Peak Hour:</b> {int(peak_count)}"
                )
                self.peak_fraud_lable.setText(peak_info)

                # Fraud Transactions per Hour graph
                self.cm_canvas.ax.clear()
                fraudulent_hours.plot(kind='bar', color='red', alpha=0.7, ax=self.cm_canvas.ax)
                self.cm_canvas.ax.set_title("Fraud Transactions by Hour")
                self.cm_canvas.ax.set_xlabel("Hour")
                self.cm_canvas.ax.set_ylabel("Number of Fraudulent Transactions")
                self.cm_canvas.ax.set_xticks(range(0, 24))
                self.cm_canvas.ax.set_xticklabels([f"{hour}:00" for hour in range(0, 24)], rotation=45)
                self.cm_canvas.ax.grid(axis='y', linestyle='--', alpha=0.7)
                self.cm_canvas.fig.tight_layout()
                self.cm_canvas.draw()

                # Apply Animation to Confusion Matrix graph
                self.animate_fade_in(self.cm_canvas, delay=500, duration=1000)
            else:
                self.peak_fraud_lable.setText("No fraud found in the dataset.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error analyzing peak fraud hours: {str(e)}")

    # Logic for File Processing
    def file_processing(self, file_location):
        try:
            data = pd.read_csv(file_location)
            scaler = StandardScaler()
            if 'Time' in data.columns and 'Amount' in data.columns:
                data[['Time', 'Amount']] = scaler.fit_transform(data[['Time', 'Amount']])
            self.data = data

            self.show_file_data(data)
            self.display_peak_fraudulent_hours(data)

            self.fraud_detection()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error processing file: {str(e)}")
            logger.error(f"Error processing file: {e}")

    # Logic to detect Fraud in dataset
    def fraud_detection(self):
        try:
            if 'Class' not in self.data.columns:
                QMessageBox.warning(self, "Error", "Dataset must contain 'Class' column for fraud detection.")
                return

            X = self.data.drop(columns=['Class'])
            y = self.data['Class']
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            chosen_model = self.select_model.currentText()

            if chosen_model == "Logistic Regression":
                model = LogisticRegression(max_iter=200)
           
            elif chosen_model == "Neural Network":
                model = self.neural_network_model(X_train.shape[1])

            if chosen_model == "Neural Network":
                model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=0)
                y_pred = (model.predict(X_test) > 0.5).astype("int32").flatten()
            else:
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                if hasattr(model, 'predict_proba'):
                    y_pred = model.predict(X_test)
                else:
                    y_pred = (y_pred > 0.5).astype(int)

            accuracy = accuracy_score(y_test, y_pred)
            self.confusion_matrix = confusion_matrix(y_test, y_pred)

            # Save Transactions with fraud
            X_test = X_test.copy()
            X_test['Predicted'] = y_pred
            self.fraud_data = X_test[X_test['Predicted'] == 1]

            # Update Confusion Matrix Graph
            self.show_cm_graph(y_test, y_pred)

            # Show Fraud count and model name along with accuracy
            fraud_count = len(self.fraud_data)
            text_insights = (
                f"<b>Model:</b> {chosen_model}<br>"
                f"<b>Accuracy:</b> {accuracy * 100:.2f}%<br>"
                f"<b>Detected Fraud Cases:</b> {fraud_count}"
            )
            self.data_insights_lable.setText(self.data_insights_lable.text() + f"<br><br>{text_insights}")

            self.animate_fade_in(self.data_insights_lable, delay=1000, duration=1000)

            # Show data in Export and Fraudulent transaction tabs if fraud detected
            if fraud_count > 0:
                self.show_fraud_btn.setEnabled(True)
            else:
                QMessageBox.information(self, "No Fraud Detected", "No fraudulent transactions detected!")
                self.show_fraud_btn.setEnabled(False)

            if chosen_model in ["Logistic Regression", "Neural Network"]:
                self.pdf_export_btn.setEnabled(True)
                self.excel_export_btn.setEnabled(True)

        except Exception as e:
            QMessageBox.critical(self, "Model Error", f"Error in model training: {str(e)}")
            logger.error(f"Model training error: {e}")

    # Display Confusion Matrix
    def show_cm_graph(self, y_test, y_pred):
        self.cm_canvas.ax.clear()
        cm = confusion_matrix(y_test, y_pred)
        sb.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=self.cm_canvas.ax, cbar=False)
        self.cm_canvas.ax.set_title("Confusion Matrix")
        self.cm_canvas.ax.set_xlabel("Predicted Label")
        self.cm_canvas.ax.set_ylabel("Actual Label")
        self.cm_canvas.fig.tight_layout()
        self.cm_canvas.draw()

    # Show transactions with Fraud
    def show_fraud_data(self):
        if self.fraud_data.empty:
             QMessageBox.warning(self, "No Data Available", "Farudulent Data is Not Available to Display")
             return

        # Entere Fraud data to the table
        self.fraud_data_table.setRowCount(len(self.fraud_data))
        self.fraud_data_table.setColumnCount(len(self.fraud_data.columns))
        self.fraud_data_table.setHorizontalHeaderLabels(self.fraud_data.columns)

        for i, (index, row) in enumerate(self.fraud_data.iterrows()):
            for j, value in enumerate(row):
                self.fraud_data_table.setItem(i, j, QTableWidgetItem(str(value)))

        # Apply Animation to Fraud Table
        self.animate_fade_in(self.fraud_data_table, delay=0, duration=1000)

    # To save Result of Detection in PDF File
    def pdf_report_generator(self):
        try:
            pdf_path, _ = QFileDialog.getSaveFileName(self, "Save PDF Report", "", "PDF Files (*.pdf)")
            
            if not pdf_path:
                QMessageBox.warning(self, "No Data Available", "Farud Detection Result is Not Available to Export as PDF File")
                return

            self.status_provider.showMessage("Generating PDF report...")
            QApplication.processEvents()

            c = canvas.Canvas(pdf_path, pagesize=letter)
            width, height = letter

            # Heading
            c.setFont("Helvetica-Bold", 16)
            c.drawString(72, height - 72, "Report of Detected Fraud")
            c.setFont("Helvetica", 12)
            c.drawString(72, height - 100, f"Selected Model: {self.select_model.currentText()}")

            # Accuracy of ML Model and Fraud Count
            text_insights = self.data_insights_lable.text().split('<br>')
            if len(text_insights) >= 3:
                text_model = text_insights[-3].replace("<b>", "").replace("</b>", "")
                text_accuracy = text_insights[-2].replace("<b>", "").replace("</b>", "")
                fraud_count = text_insights[-1].replace("<b>", "").replace("</b>", "")
            else:
                text_model = "Selected Model information not available."
                text_accuracy = "Accuracy of Model information not available."
                fraud_count = "Fraud count information not available."

            c.drawString(72, height - 120, text_model)
            c.drawString(72, height - 140, text_accuracy)
            c.drawString(72, height - 160, fraud_count)

            # Confusion Matrix
            cm_img_position = "confusion_matrix.png"
            self.save_cm_img(cm_img_position)
            c.drawImage(cm_img_position, 72, height - 400, width=250, height=200)

            # Transaction Trends over Time
            trends_img_position = "transaction_trends.png"
            self.save_transaction_trends_img(trends_img_position)
            c.drawImage(trends_img_position, 350, height - 400, width=250, height=200)

            # Save PDF
            c.showPage()
            c.save()

            QMessageBox.information(self, "Report Generated", f"PDF report saved to {pdf_path}")
            self.status_provider.showMessage("PDF Report generated successfully!", 5000)
        except Exception as e:
            QMessageBox.critical(self, "Report Error", f"Failed to generate PDF Report: {str(e)}")
            logger.error(f"PDF report generation error: {e}")
            self.status_provider.showMessage("Failed to generate PDF report!", 5000)

    # To save COnfusion Matrix image in PDF
    def save_cm_img(self, path):
        plt.figure(figsize=(6, 4))
        sb.heatmap(self.confusion_matrix, annot=True, fmt="d", cmap="Blues", cbar=False)
        plt.title("Confusion Matrix")
        plt.xlabel("Predicted Label")
        plt.ylabel("Actual Label")
        plt.tight_layout()
        plt.savefig(path)
        plt.close()

    # To save Transaction Trends Over Time image in PDF
    def save_transaction_trends_img(self, path):
        plt.figure(figsize=(10, 6))

        # Regular transactions graph in blue color
        regular_transactions = self.data[self.data['Class'] == 0]
        plt.scatter(regular_transactions['Time'], regular_transactions['Amount'], 
                    color='blue', alpha=0.5, label='Transactions without Fraud')

        # Transactions with Fraud graph in red color
        fraudulent_transactions = self.data[self.data['Class'] == 1]
        plt.scatter(fraudulent_transactions['Time'], fraudulent_transactions['Amount'], 
                    color='red', alpha=0.7, label='Fraudulent Transactions')

        plt.title("Transaction Amounts Over Time")
        plt.xlabel("Time")
        plt.ylabel("Transaction Amount")
        plt.legend(loc='upper right')
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(path)
        plt.close()

    # To export result in Exel File
    def excel_report_generator(self):
        try:
            excel_path, _ = QFileDialog.getSaveFileName(self, "Save Excel Report", "", "Excel Files (*.xlsx)")
            if not excel_path:
                 QMessageBox.warning(self, "No Data Available", "Farud Detection Result is Not Available to Export as Excel File")
                 return

            self.status_provider.showMessage("Generating Excel report...")
            QApplication.processEvents()

            # Extracting text without HTML tags
            text_insights = self.data_insights_lable.text().split('<br>')
            if len(text_insights) >= 3:
                text_model = text_insights[-3].replace("<b>", "").replace("</b>", "").split(": ")[1]
                text_accuracy = text_insights[-2].replace("<b>", "").replace("</b>", "").split(": ")[1] 
                fraud_count = text_insights[-1].replace("<b>", "").replace("</b>", "").split(": ")[1]
            else:
                text_model = "Selected Model information not available."
                text_accuracy = "Accuracy of Model information not available."
                fraud_count = "Fraud count information not available."

            data = {
                "Selected Model": [text_model],
                "Accuracy": [text_accuracy],
                "Fraud Count": [fraud_count]
            }
            df = pd.DataFrame(data)
            
            with pd.ExcelWriter(excel_path) as writer:
                df.to_excel(writer, sheet_name='Summary', index=False)

                if not self.fraud_data.empty:
                    self.fraud_data.to_excel(writer, sheet_name='Fraudulent Transactions')

            QMessageBox.information(self, "Report Generated", f"Excel Report saved to {excel_path}")
            self.status_provider.showMessage("Excel Report generated successfully!", 5000)
        except Exception as e:
            QMessageBox.critical(self, "Report Error", f"Failed to Generate Excel Report: {str(e)}")
            logger.error(f"Excel report generation error: {e}")
            self.status_provider.showMessage("Failed to Generate Excel Report!", 5000)

    # Logic for enabling or disabling Dark mode
    def enable_dark_mode(self):
        if self.dark_mode_btn.text() == "Enable Dark Mode":
            dark_style = """
                QWidget {
                    background-color: #2b2b2b;
                    color: #f0f0f0;
                }
                QPushButton {
                    background-color: #4CAF50;
                    color: white;
                    padding: 10px 20px;
                    font-size: 16px;
                    border-radius: 10px;
                }
                QPushButton:hover {
                    background-color: #45a049;
                }
                QLineEdit, QComboBox, QTableWidget {
                    background-color: #3c3c3c;
                    color: #f0f0f0;
                    border: 1px solid #555555;
                }
                QLabel {
                    color: #f0f0f0;
                }
                QTabWidget::pane { /* The tab widget frame */
                    border-top: 2px solid #C2C7CB;
                }
                QTabBar::tab {
                    background: #3c3c3c;
                    color: #f0f0f0;
                    padding: 10px;
                }
                QTabBar::tab:selected {
                    background: #4CAF50;
                }
            """
            self.setStyleSheet(dark_style)
            self.dark_mode_btn.setText("Enable Light Mode")
        else:
            light_style = """
              QWidget {
                    background-color: white;
                    color: black;
                }
                QPushButton {
                    background-color: #4CAF50;
                    color: white;
                    padding: 10px 20px;
                    font-size: 16px;
                    border: 1px solid #4CAF50; 
                    border-radius: 10px;
                }
                QPushButton:hover {
                    background-color: #45a049;
                }
                QLineEdit, QComboBox, QTableWidget {
                    background-color: white;
                    color: #3c3c3c;
                    border: 1px solid #555555;
                }
                QLabel {
                    color: #2b2b2b;
                }
                QTabWidget::pane
                    border-top: 2px solid #d8d8d8;
                }
                QTabBar::tab {
                    background: silver;
                    color: #3c3c3c;
                    padding: 10px;
                }
                QTabBar::tab:selected {
                    background: #4CAF50;
                }
            """
            self.setStyleSheet(light_style)
            self.dark_mode_btn.setText("Enable Dark Mode")

    # Fade-in animation for entire design
    def animate_fade_in(self, widget, delay=0, duration=1000):
        opacity = QGraphicsOpacityEffect()
        widget.setGraphicsEffect(opacity)
        opacity.setOpacity(0)

        group = QSequentialAnimationGroup()

        if delay > 0:
            # Add a pause if delay is specified
            pause = QPauseAnimation(delay)
            group.addAnimation(pause)

        # Desin fade-in property 
        fade_in_animation = QPropertyAnimation(opacity, b"opacity")
        fade_in_animation.setDuration(duration)
        fade_in_animation.setStartValue(0)
        fade_in_animation.setEndValue(1)
        fade_in_animation.setEasingCurve(QEasingCurve.InOutQuad)
        group.addAnimation(fade_in_animation)

        # Start the animation
        group.start()
        widget.group = group

    # Creating hover animation for buttons
    def animate_hover(self, widget):
       
        widget.setProperty("hover", False)
        widget.installEventFilter(self)

    # defining filter for hover animation
    def eventFilter(self, source, event):
        if event.type() == event.Enter and isinstance(source, (QPushButton, QComboBox)):
            # Start animation
            hover_animation = QPropertyAnimation(source, b"geometry")
            hover_animation.setDuration(200)
            current_rect = source.geometry()
            hover_animation.setStartValue(current_rect)
            hover_animation.setEndValue(QRect(current_rect.x()-2, current_rect.y()-2, current_rect.width()+4, current_rect.height()+4))
            hover_animation.setEasingCurve(QEasingCurve.OutBounce)
            hover_animation.start()
            source.animate_hover = hover_animation 
        elif event.type() == event.Leave and isinstance(source, (QPushButton, QComboBox)):
            # End animation
            hover_animation = QPropertyAnimation(source, b"geometry")
            hover_animation.setDuration(200)
            current_rect = source.geometry()
            original_rect = QRect(current_rect.x()+2, current_rect.y()+2, current_rect.width()-4, current_rect.height()-4)
            hover_animation.setStartValue(current_rect)
            hover_animation.setEndValue(original_rect)
            hover_animation.setEasingCurve(QEasingCurve.OutBounce)
            hover_animation.start()
            source.animate_hover = hover_animation
        return super().eventFilter(source, event)

# User database initialization
def user_db_initialization():
    try:
        conn = sqlite3.connect(config.get("DATABASE", "database_name", "users.db"))
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password BLOB
            )
        """)
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Error initializing database: {e}")

if __name__ == '__main__':
    user_db_initialization()
    main_app = QApplication(sys.argv)

    # Add application logo
    main_app.setWindowIcon(QIcon("icons/app_icon.png"))  

    # Execute Application
    login_window = Login()
    if login_window.exec_() == QDialog.Accepted:
        main_window = FraudAnalyzerApplication()
        main_window.show()
        sys.exit(main_app.exec_())