import logging
import configparser

# Configuration management
class ConfigManager:
    def __init__(self, config_file='config.ini'):
        self.config = configparser.ConfigParser()
        self.config.read(config_file)

    def get(self, section, option, fallback=None):
        return self.config.get(section, option, fallback=fallback)

# Application logger setup
class Logger:
    def __init__(self, log_file='application.log'):
        self.logger = logging.getLogger('FraudAnalyzerApp')
        self.logger.setLevel(logging.DEBUG)
        
        # To write logs to a file
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)

        # To output logs in the console
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)

        # Logging format
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Add handlers
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)

    def get_logger(self):
        return self.logger