from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import os
import xlsxwriter

class GenerateReport:
    def __init__(self, output_folder="reports"):
        self.output_folder = output_folder
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

    def pdf_report_generator(self, data, filename="report.pdf"):
        report_path = os.path.join(self.output_folder, filename)
        c = canvas.Canvas(report_path, pagesize=letter)
        c.drawString(100, 760, "Report of Fraud Detection")
        c.drawString(100, 740, f"Model: {data['model']}")
        c.drawString(100, 730, f"Accuracy: {data['accuracy']}")
        c.drawString(100, 710, "Confusion Matrix:")
        
        # Confusion matrix
        y = 680
        for row in data['confusion_matrix']:
            c.drawString(100, y, str(row))
            y -= 15
        c.save()
        return report_path

    def excel_report_generator(self, data, filename="report.xlsx"):
        report_path = os.path.join(self.output_folder, filename)
        workbook = xlsxwriter.Workbook(report_path)
        worksheet = workbook.add_worksheet()

        worksheet.write("A1", "Report of Fraud Detection")
        worksheet.write("A2", f"Model: {data['model']}")
        worksheet.write("A3", f"Accuracy: {data['accuracy']}")
        worksheet.write("A5", "Confusion Matrix")

        row = 5
        for i, actual_row in enumerate(data['confusion_matrix']):
            for j, value in enumerate(actual_row):
                worksheet.write(row + i, j, value)

        workbook.close()
        return report_path
       
    def generate_pdf_report(self, data):
         # Define the report path
         report_path = "fraud_detection_report.pdf"
         c = canvas.Canvas(report_path, pagesize=letter)
         width, height = letter

         # Heading
         c.setFont("Helvetica-Bold", 20)
         c.drawCentredString(width / 2, height - 50, "Report of Fraud Detection")

         # ML Model Information
         c.setFont("Helvetica", 12)
         model_detail = f"Model Used: {data['model']}\nAccuracy: {data['accuracy']}\nDetected Fraud Cases: {len(data['fraud_cases'])}"
         c.drawString(50, height - 100, model_detail)

         # Detail of the Confusion Matrix
         c.setFont("Helvetica-Bold", 14)
         c.drawString(50, height - 140, "Confusion Matrix:")
         c.setFont("Helvetica", 10)
         confusion_desc = (
            "Confusion Matrix."
         )
         c.drawString(50, height - 160, confusion_desc)

         # Set Confusion Matrix Image
         c.drawImage(data['confusion_matrix_img'], 50, height - 320, width=200, height=150)

         # Description of the confusion matrix values
         cm_details = (
            f"True Negatives (TN): {data['confusion_matrix'][0][0]} - Non-fraud cases correctly classified.\n"
            f"False Positives (FP): {data['confusion_matrix'][0][1]} - Non-fraud cases incorrectly classified as fraud.\n"
            f"False Negatives (FN): {data['confusion_matrix'][1][0]} - Fraud cases incorrectly classified as non-fraud.\n"
            f"True Positives (TP): {data['confusion_matrix'][1][1]} - Fraud cases correctly classified."
         )
         c.drawString(50, height - 350, cm_details)

         # Transaction Amount Trend
         c.setFont("Helvetica-Bold", 14)
         c.drawString(50, height - 420, "Transaction Amount Trends Over Time:")
         c.setFont("Helvetica", 10)
         trend_desc = (
            "Transaction Graph."
         )
         c.drawString(50, height - 440, trend_desc)

         # Set Transaction Amount Graph 
         c.drawImage(data['transaction_trend_img'], 300, height - 320, width=200, height=150)

         # Summary
         c.setFont("Helvetica-Bold", 14)
         c.drawString(50, height - 510, "Summary:")
         c.setFont("Helvetica", 10)
         summary_text = (
            "Nothing"
         )
         c.drawString(50, height - 530, summary_text)

         # Save PDF
         c.save()
         return report_path